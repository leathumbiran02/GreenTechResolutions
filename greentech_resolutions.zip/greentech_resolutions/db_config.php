<?php
    /*Database details on localhost: */
    //Storing the database details:
    define('DB_HOST','localhost');
    define('DB_USER','root');
    define('DB_PASSWORD', 'password');
    define('DB_NAME','greentech_resolutions');
?>